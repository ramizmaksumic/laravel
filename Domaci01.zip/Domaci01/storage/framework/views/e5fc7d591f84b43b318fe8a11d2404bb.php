 

 <?php $__env->startSection("heading"); ?>

 <?php $heading = "All Contacts";
    echo $heading; ?>
 <?php $__env->stopSection(); ?>


 <?php $__env->startSection("glavnastranica"); ?>

 <div class="flex justify-end">
     <div class="text-2xl text-blue-800 font-black rounded-full flex items-center justify-center mb-8 p-2">
         <a href="/contact">Unesite novi kontakt +</a>
     </div>
 </div>




 <table class="table-auto" style="border: 1px solid black; width: 1200px; align-content:center">
     <thead>
         <tr>
             <th>Name</th>
             <th>Email</th>
             <th>Password</th>
             <th>ID</th>
             <th>Action</th>

         </tr>
     </thead>
     <tbody>

         <?php $__currentLoopData = $allcontacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleContact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


         <tr>
             <td style="border: 1px solid black"><?php echo e($singleContact->name); ?></td>
             <td style="border: 1px solid black"><?php echo e($singleContact->email); ?></td>
             <td style="border: 1px solid black"><?php echo e($singleContact->password); ?></td>
             <td style="border: 1px solid black"><?php echo e($singleContact->id); ?></td>
             <td style="border: 1px solid black">
                 <a style="color:red; font-weight: 700;" href=" /admin/delete-contact/<?php echo e($singleContact->id); ?>">Delete</a>
                 <a style="color:blue; font-weight: 700;" href="/admin/edit-contact/<?php echo e($singleContact->id); ?>">Edit</a>
             </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </tbody>
 </table>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\aa\Desktop\LaravelDomaci\Domaci01\resources\views/allContacts.blade.php ENDPATH**/ ?>