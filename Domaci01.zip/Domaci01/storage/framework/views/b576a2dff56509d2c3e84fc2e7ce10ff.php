 

 <?php $__env->startSection("heading"); ?>

 <?php $heading = "Add products";
    echo $heading; ?>
 <?php $__env->stopSection(); ?>

 <?php $__env->startSection("glavnastranica"); ?>


 <p>Putem ove forme možete dodati nove proizvode</p>
 <form action="/admin/add-products" method="POST" class="mt-4 flex flex-col w-3xl">
     <?php echo csrf_field(); ?>
     <label for="name" class="text-xl font-bold">Naziv proizvoda</label>
     <input type="text" name="name" class="bg-white p-3 mt-2">
     <label for="description" class="text-xl font-bold">Description</label>
     <textarea name="description" id="" class="bg-white p-3 mt-2"></textarea>
     <label for="amount" class="text-xl font-bold">Amount</label>
     <input type="number" name="amount" class="bg-white p-3 mt-2">
     <label for="price" class="text-xl font-bold">Price</label>
     <input type="number" name="price" class="bg-white p-3 mt-2">
     <label for="image" class="text-xl font-bold">Image</label>
     <input type="file" name="image" class="bg-white p-3 mt-2">


     <input type="submit" value="Send" class="bg-blue-500 text-white font-700 p-3 mt-8">
 </form>

 <?php if($errors->any()): ?>

 <p>Desila se greška: <?php echo e($errors->first()); ?></p>

 <?php endif; ?>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\aa\Desktop\LaravelDomaci\Domaci01\resources\views/admin.blade.php ENDPATH**/ ?>