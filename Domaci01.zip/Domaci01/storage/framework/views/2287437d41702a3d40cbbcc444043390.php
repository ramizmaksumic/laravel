<?php echo $__env->make('nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
    <?php echo $__env->yieldContent('glavnastranica'); ?>
</div>
<?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\aa\Desktop\LaravelDomaci\Domaci01\resources\views/layout.blade.php ENDPATH**/ ?>