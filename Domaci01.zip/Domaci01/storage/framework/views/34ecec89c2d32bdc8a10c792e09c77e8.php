 

 <?php $__env->startSection("heading"); ?>

 <?php $heading = "Shop";
   echo $heading; ?>
 <?php $__env->stopSection(); ?>

 <?php $__env->startSection("glavnastranica"); ?>


 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <p><?php echo e($product->name); ?></p>
 <p><?php echo e($product->description); ?></p>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\aa\Desktop\LaravelDomaci\Domaci01\resources\views/shop.blade.php ENDPATH**/ ?>