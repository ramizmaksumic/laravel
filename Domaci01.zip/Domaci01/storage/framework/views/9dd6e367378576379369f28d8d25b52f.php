    

    <?php $__env->startSection("heading"); ?>

    <?php $heading = "All Products";
    echo $heading; ?>
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection("glavnastranica"); ?>

    <div class="flex justify-end">
        <div class="text-2xl text-blue-800 font-black rounded-full flex items-center justify-center mb-8 p-2">
            <a href="/admin/add-products">Unesite novi proizvod +</a>
        </div>
    </div>


    <table style="border: 1px solid black; width: 1200px; align-content:center">
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Amount</th>
            <th>Image</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style="border: 1px solid black">
            <td style="border: 1px solid black"><?php echo e($product->name); ?></td>
            <td style="border: 1px solid black"><?php echo e($product->description); ?></td>
            <td style="border: 1px solid black"><?php echo e($product->price); ?></td>
            <td style="border: 1px solid black"><?php echo e($product->amount); ?></td>
            <td style="border: 1px solid black"><?php echo e($product->image); ?></td>
            <td style="border: 1px solid black"><a href="/admin/delete-product/<?php echo e($product->id); ?>" style="background-color: red; padding: 2px 10px; margin: 5px; color: #fff; border: 1px solid #fff;  ">Delete</a>
                <a href="/admin/single-product/<?php echo e($product->id); ?>" style="background-color: blue; padding: 2px 10px; margin: 5px; color: #fff; border: 1px solid #fff;  ">Edit</a>
            </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\aa\Desktop\LaravelDomaci\Domaci01\resources\views/products.blade.php ENDPATH**/ ?>