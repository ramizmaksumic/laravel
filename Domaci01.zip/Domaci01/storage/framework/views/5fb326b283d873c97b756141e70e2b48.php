  

  <?php $__env->startSection("heading"); ?>

  <?php $heading = "About Us";
    echo $heading; ?>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection("glavnastranica"); ?>

  <h1>About</h1>
  <p>Ovo je about stranica</p>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\aa\Desktop\LaravelDomaci\Domaci01\resources\views/about.blade.php ENDPATH**/ ?>