    

    <?php $__env->startSection("heading"); ?>

    <?php $heading = "Dashboard";
    echo $heading; ?>
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection("glavnastranica"); ?>

    <div class="flex justify-end">
        <div class="text-2xl text-blue-800 font-black rounded-full flex items-center justify-center mb-8 p-2">
            <a href="/admin/add-products">Unesite novi proizvod +</a>
        </div>
    </div>



    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class=" p-4 bg-white mb-3 hover:bg-blue-50">

        <p class="font-bold"><a href=""><?php echo e($product->name); ?> - <?php echo e($product->price); ?></a></p>
        <p "><?php echo e($product->description); ?></p>

    </div>

   


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br>
            
<a href=" /admin/all-products" class="bg-blue-800 p-3 mt-3 text-white font-bold">Vidi sve proizvode</a>
            <a href=" /admin/all-contacts" class="bg-blue-500 p-3 mt-3 text-white font-bold">Vidi sve kontakte</a>


            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\aa\Desktop\LaravelDomaci\Domaci01\resources\views/welcome.blade.php ENDPATH**/ ?>