</main>
</div>

<footer class="bg-black text-white flex justify-center p-3">
    <p>Sva prava zadržana Ramiz Maksumić | &copy; 2025</p>
</footer>

</body>


</html><?php /**PATH C:\Users\aa\Desktop\LaravelDomaci\Domaci01\resources\views/footer.blade.php ENDPATH**/ ?>