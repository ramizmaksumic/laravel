  @extends('layout')

  @section("heading")

  <?php $heading = "About Us";
    echo $heading; ?>
  @endsection

  @section("glavnastranica")

  <h1>About</h1>
  <p>Ovo je about stranica</p>
  @endsection